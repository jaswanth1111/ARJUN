myJSON = '{"name":"John", "age":30, "car":null}';
myObj = JSON.Parse(myJSON);